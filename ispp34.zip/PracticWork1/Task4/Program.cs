﻿
Console.Write("Введите имя папки: ");
string folderPath = Console.ReadLine();

Console.Write("Введите часть имени файла: ");
string filePart = Console.ReadLine();

if (Directory.Exists(folderPath))
{
    var files = Directory.GetFiles(folderPath, "*.*", SearchOption.AllDirectories);

    Console.WriteLine("Найденные файлы:");
    foreach (var file in files)
    {
        if (Path.GetFileName(file).Contains(filePart))
        {
            FileInfo fileInfo = new FileInfo(file);
            Console.WriteLine($"Имя: {fileInfo.FullName}, Размер: {fileInfo.Length} байт");
        }
    }
}
else
{
    Console.WriteLine("Указанная папка не существует.");
}
