﻿Console.Write("Введите имя папки: ");
string sourceFolderPath = Console.ReadLine();

if (Directory.Exists(sourceFolderPath))
{
    var files = Directory.GetFiles(sourceFolderPath);

    foreach (var file in files)
    {
        FileInfo fileInfo = new FileInfo(file);
        DateTime lastModified = fileInfo.LastWriteTime;

        string targetFolderPath = Path.Combine(sourceFolderPath, lastModified.Year.ToString(),
                                                lastModified.Month.ToString("D2"),
                                                lastModified.Day.ToString("D2"));

        if (!Directory.Exists(targetFolderPath))
        {
            Directory.CreateDirectory(targetFolderPath);
        }

        string targetFilePath = Path.Combine(targetFolderPath, fileInfo.Name);
        File.Move(file, targetFilePath);
        Console.WriteLine($"Файл {fileInfo.Name} перемещен в {targetFilePath}");
    }
}
else
{
    Console.WriteLine("Указанная папка не существует.");
}
