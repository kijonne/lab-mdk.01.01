﻿
Console.Write("Введите имя файла: ");
string fileName = Console.ReadLine();

if (File.Exists(fileName))
{
    Console.WriteLine("Файл открыт на дозапись.");
}
else
{
    Console.WriteLine("Файл с указанным названием будет создан.");
}

Console.WriteLine("Введите строки для записи в файл (введите 'end' для завершения):");
string input;

while (true)
{
    input = Console.ReadLine();

    if (input.Equals("end", StringComparison.OrdinalIgnoreCase))
    {
        break;
    }

    File.AppendAllText(fileName, input + Environment.NewLine);
}

Console.WriteLine($"Запись в файл '{fileName}' завершена.");
