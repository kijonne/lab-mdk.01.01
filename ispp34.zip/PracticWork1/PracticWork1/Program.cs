﻿Console.Write("Введите имя файла: ");
string fileName = Console.ReadLine();

if (File.Exists(fileName))
{
    try
    {
        string fileContent = File.ReadAllText(fileName);
        Console.WriteLine("Содержимое файла:");
        Console.WriteLine(fileContent);
    }
    catch (Exception ex)
    {
        Console.WriteLine(" ошибка при чтении файла: " + ex.Message);
    }
}
else
{
    Console.WriteLine("Файл не существует.");
}
