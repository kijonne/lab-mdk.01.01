﻿using System.Text;

Console.Write("введите имя файла: ");
string fileName = Console.ReadLine();

if (File.Exists(fileName))
{
    Console.WriteLine("Файл открыт на дозапись.");
}
else
{
    Console.WriteLine("Файл с указанным названием будет создан.");
}

Console.WriteLine("Введите строки для записи в файл (введите 'end' для завершения):");
string input;
StringBuilder stringBuilder = new();
while (true)
{
    input = Console.ReadLine();

    if (input.Equals("end", StringComparison.OrdinalIgnoreCase))
    {
        break;
    }
    stringBuilder.AppendLine(input);
}
File.AppendAllText(fileName, stringBuilder.ToString());

Console.WriteLine($"Запись в файл '{fileName}' завершена.");
