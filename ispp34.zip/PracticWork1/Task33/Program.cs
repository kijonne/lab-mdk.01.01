﻿Console.WriteLine("Введите текст для поиска:");
string searchText = Console.ReadLine();

Console.WriteLine("Введите имя текстового файла:");
string fileName = Console.ReadLine();

if (File.Exists(fileName))
{
    string[] lines = File.ReadAllLines(fileName);
    bool isFound = false;

    for (int i = 0; i < lines.Length; i++)
    {
        if (lines[i].Contains(searchText, StringComparison.OrdinalIgnoreCase))
        {
            Console.WriteLine($"Строка {i + 1}: {lines[i]}");
            isFound = true;
        }
    }

    if (!isFound)
    {
        Console.WriteLine("Текст не найден в файле.");
    }
}
else
{
    Console.WriteLine("Файл не существует.");
}
