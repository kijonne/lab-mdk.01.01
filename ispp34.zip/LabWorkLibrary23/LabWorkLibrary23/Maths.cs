﻿namespace LabWorkLibrary23
{
    /// <summary>
    /// класс для выполнения математических операций
    /// </summary>
    public static class Maths
    {
        /// <summary>
        /// константа со значением 2^10
        /// </summary>
        public const int BinaryFactor = 1024;

        /// <summary>
        /// вычисляет сумму двух чисел.
        /// </summary>
        /// <param name="a">первое слагаемое.</param>
        /// <param name="b">второе слагаемое.</param>
        /// <returns>сумма двух чисел.</returns>
        public static double Add(double a, double b) => a + b;

        /// <summary>
        /// вычисляет разность двух чисел.
        /// </summary>
        /// <param name="a">уменьшаемое.</param>
        /// <param name="b">вычитаемое.</param>
        /// <returns>разность.</returns>
        public static double Subtract(double a, double b) => a - b;

        /// <summary>
        /// вычисляет произведение двух чисел.
        /// </summary>
        /// <param name="a">первый множитель.</param>
        /// <param name="b">второй множитель.</param>
        /// <returns>произведение.</returns>
        public static double Multiply(double a, double b) => a * b;

        /// <summary>
        /// делит одно число на другое.
        /// </summary>
        /// <param name="a">делимое.</param>
        /// <param name="b">делитель.</param>
        /// <returns>частное.</returns>
        /// <exception cref="DivideByZeroException">возникает при делении на ноль</exception>
        public static double Divide(double a, double b)
        {
            if (b == 0)
                throw new DivideByZeroException("на ноль делить нелзя.");
            return (double)a / b;
        }

        /// <summary>
        /// вычисляет площадь прямоугольника.
        /// </summary>
        /// <param name="width">ширина прямоугольника.</param>
        /// <param name="height">высота прямоугольника.</param>
        /// <returns>площадь прямоугольника.</returns>
        /// <exception cref="ArgumentException">возникает когда данные некорректны.</exception>
        public static double RectangleArea(double width, double height)
        {
            if (width <= 0 || height <= 0)
                throw new ArgumentException("ширина и высота должны быть больше нуля.");
            return width * height;
        }
    }
}

