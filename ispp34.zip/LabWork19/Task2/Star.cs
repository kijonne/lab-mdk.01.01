﻿public class Star : IShape
{
    public void Draw() => Console.WriteLine("Внутри Star::draw() метод.");
}