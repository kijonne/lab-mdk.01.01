﻿public class Square : IShape
{
    public void Draw() => Console.WriteLine("Внутри Square::draw() метод.");
}