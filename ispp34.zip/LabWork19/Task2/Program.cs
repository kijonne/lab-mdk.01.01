﻿ShapeFactory shapeFactory = new();

IShape shape1 = shapeFactory.GetShape("КРУГ");

shape1.Draw();

IShape shape2 = shapeFactory.GetShape("ПРЯМОУГОЛЬНИК");

shape2.Draw();

IShape shape3 = shapeFactory.GetShape("КВАДРАТ");

shape3.Draw();

IShape shape4 = shapeFactory.GetShape("ЗВЕЗДА");

shape4.Draw();