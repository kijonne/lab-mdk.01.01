﻿public class Rectangle : IShape
{
    public void Draw() => Console.WriteLine("Внутри Rectangle::draw() метод.");
}