﻿using System.Drawing;

public class ShapeFactory
{
    public IShape? GetShape(string shapeType)
    {
        if (string.IsNullOrEmpty(shapeType))
            return null;
        if (shapeType.Equals("КРУГ", StringComparison.OrdinalIgnoreCase))
            return new Circle();
        if (shapeType.Equals("ПРЯМОУГОЛЬНИК", StringComparison.OrdinalIgnoreCase))
            return new Rectangle();
        if (shapeType.Equals("КВАДРАТ", StringComparison.OrdinalIgnoreCase))
            return new Square();
        if (shapeType.Equals("ЗВЕЗДА", StringComparison.OrdinalIgnoreCase))
            return new Star();

        return null;
    }
}
