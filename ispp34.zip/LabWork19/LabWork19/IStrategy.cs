﻿public interface IStrategy
{
    public int DoOperation(int number1, int number2);
}