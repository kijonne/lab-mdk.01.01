﻿public class OperationDivision : IStrategy
{
    public int DoOperation(int number1, int number2)
    {
        return number1 / number2;
    }
}