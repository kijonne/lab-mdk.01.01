﻿public interface IShape
{
    void Draw();
}


