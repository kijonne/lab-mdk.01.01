﻿IShape circle = new Circle();

RedShapeDecorator RedCircle = new(new Circle());

RedShapeDecorator RedRectangle = new(new Rectangle());

PurpleShapeDecorator PurpleCircle = new(new Circle());

Console.WriteLine("Круг с обычной окантовкой");
circle.Draw();

Console.WriteLine("\nКруг с красной окантовкой");
RedCircle.Draw();

Console.WriteLine("\nПрямоугольник с красной окантовкой ");
RedRectangle.Draw();

Console.WriteLine("\nКруг с фиолетовой окантовкой");
PurpleCircle.Draw();
