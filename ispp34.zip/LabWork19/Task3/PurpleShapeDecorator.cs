﻿public class PurpleShapeDecorator : ShapeDecorator
{
    public PurpleShapeDecorator(IShape decoratedShape) : base(decoratedShape) { }

    public void Draw()
    {
        decoratedShape.Draw();
        PurpleBorder(decoratedShape);
    }

    private void PurpleBorder(IShape DecoratedShape)
    {
        Console.WriteLine("Цвет окантовки: фиолетовый");
    }
}
