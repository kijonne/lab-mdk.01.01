﻿public class RedShapeDecorator : ShapeDecorator
{
    public RedShapeDecorator(IShape decoratedShape) : base(decoratedShape) { }

    public void Draw()
    {
        decoratedShape.Draw();
        RedBorder(decoratedShape);
    }

    private void RedBorder(IShape DecoratedShape)
    {
        Console.WriteLine("Цвет окантовки: красный");
    }
}
