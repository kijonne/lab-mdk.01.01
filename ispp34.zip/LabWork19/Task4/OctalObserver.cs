﻿public class OctalObserver : Observer
{

    public OctalObserver(Subject subject)
    {
        _subject = subject;
        _subject.attach(this);
    }

    public override void update()
    {
        Console.WriteLine("Octal String: " + _subject.getState().ToString("X"));
    }
}