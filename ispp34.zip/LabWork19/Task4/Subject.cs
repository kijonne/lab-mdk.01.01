﻿using System;

public class Subject
{
    private List<Observer> _observers = new List<Observer>();
    private int _state;

    public int getState()
    {
        return _state;
    }

    public void setState(int state)
    {
        _state = state;
        notifyAllObservers();
    }

    public void attach(Observer observer)
    {
        _observers.Add(observer);
    }

    public void notifyAllObservers()
    {
        foreach (var observer in _observers)
        {
            observer.update();
        }
    }
}