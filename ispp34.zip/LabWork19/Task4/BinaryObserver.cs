﻿public class BinaryObserver : Observer
{
    public BinaryObserver(Subject subject)
    {
        _subject = subject;
        _subject.attach(this);
    }

    public override void update()
    {
        Console.WriteLine("Binary String: " + Convert.ToString(_subject.getState(),2));
    }
}