﻿public class HexaObserver : Observer
{
    public HexaObserver(Subject subject)
    {
        _subject = subject;
        _subject.attach(this);
    }

    public override void update()
    {
        Console.WriteLine("Hex String: " + Convert.ToString(_subject.getState()).ToUpper());
    }
}