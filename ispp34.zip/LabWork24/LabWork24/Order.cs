﻿public class Order : OrderService
{
    public int Id { get; set; }

    private double total;

    public double Total
    {
        get => total;
        set
        {
            if (value < 0)
                throw new ArgumentException("Стоимость заказа не может быть отрицательной.");
            total = value;
        }
    }

    public bool IsExpress { get; set; }

    private string address;
    public string Address
    {
        get => address;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Адрес не может быть пустым.");
            address = value;
        }
    }

    private const double TaxRate = 0.2; // налог 20%
    private const double DiscountThreshold = 10000; // порог для получения скидки
    private const double DiscountRate = 0.1; // скидка
    private ShippingService shippingService = new();

    public double CalculateTotalPrice() // вычисляет итоговую сумму
    {
        if (Address is null)
            throw new OrderException("Адрес не указан.");

        double discount = CalculateDiscountCost();
        double deliveryCost = shippingService.CalculateDeliveryCost(Total, IsExpress);
        double tax = CalculateTax();

        return Total - discount + tax + deliveryCost;
    }

    private double CalculateTax()
    {
        return Total * TaxRate;
    }

    private double CalculateDiscountCost()
    {
        return Total > DiscountThreshold ? Total * DiscountRate : 0;
    }
}
