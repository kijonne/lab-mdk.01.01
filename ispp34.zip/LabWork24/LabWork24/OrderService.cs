﻿public class OrderService
{
    private List<Order> orders { get; set; } = new List<Order>();

    public void AddOrder(Order order)
    {
        orders.Add(order); // доб. новый заказ
    }

    public void PrintOrderDetails(int orderId)
    {
        var order = orders.FirstOrDefault(order => order.Id == orderId);

        if (order == null)
        {
            Console.WriteLine("Заказ не найден.");
            return;
        }

        Console.WriteLine("Order Id: " + order.Id);
        Console.WriteLine("Стоимость заказа: " + order.Total);
        Console.WriteLine("Адрес: " + order.Address);
        Console.WriteLine("Экспресс доставка: " + (order.IsExpress ? "Да" : "Нет"));
    }
}
