﻿string[] fileNames = { 
    "C:\\Temp\\ispp34\\ispp45.txt",
    "C:\\Temp\\ispp34\\ispp455.txt",
    "C:\\Temp\\ispp34\\ispp3445.txt" 
};

Task[] readTasks = new Task[fileNames.Length];

for (int i = 0; i < fileNames.Length; i++)
{
    readTasks[i] = ReadFileAsync(fileNames[i]);
}

await Task.WhenAll(readTasks);

static async Task ReadFileAsync(string fileName)
{
    Console.WriteLine($"чтение из файла {fileName} начато");

    using (StreamReader reader = new(fileName))
    {
        string line;
        while ((line = await reader.ReadLineAsync()) != null)
        {
            Console.WriteLine($"{fileName}: {line}");
        }
    }

    Console.WriteLine($"чтение из файла {fileName} закончено");
}
