﻿
class Program
{
    static void CalculatePower(double a, int x)
    {
        double result = Math.Pow(a, x);
        Console.WriteLine($"{a}^{x} = {result}");
    }

    static async Task Main(string[] args)
    {
        Console.WriteLine("последовательный вызов:");
        await Task.Run(() => CalculatePower(2, 3));
        await Task.Run(() => CalculatePower(3, 2));
        await Task.Run(() => CalculatePower(5, 0));

        Console.WriteLine("параллельный вызов:");

        Task task1 = Task.Run(() => CalculatePower(2, 3));
        Task task2 = Task.Run(() => CalculatePower(5, 0));
        Task task3 = Task.Run(() => CalculatePower(3, 2));

        await Task.WhenAll(task1, task2, task3);
    }
}
