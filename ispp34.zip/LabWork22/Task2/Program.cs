﻿string fileName = "C:\\Temp\\ispp34\\ispp45.txt";
int numbersCount = 500000;

await WriteRandomNumbersAsync(fileName, numbersCount);
Console.WriteLine("Конец программы");

static async Task WriteRandomNumbersAsync(string fileName, int numbersCount)
{
    Console.WriteLine($"Запись в файл {fileName} начата");

    using (StreamWriter writer = new(fileName, false))
    {
        Random random = new();

        for (int i = 1; i <= numbersCount; i++)
        {
            int randomNumber = random.Next(1, 1001);
            await writer.WriteLineAsync($"Число {i}: {randomNumber}");
        }
    }

    Console.WriteLine($"запись в файл {fileName} окончена");
}

