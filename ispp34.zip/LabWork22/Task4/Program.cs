﻿using System.Security.Cryptography;

string directoryPath = @"Y:\МДК.01.01";

var files = Directory.GetFiles(directoryPath);

foreach (var file in files)
{
    var hashTask = CalculateFileHashAsync(file);
    hashTask.Wait();
    Console.WriteLine(hashTask.Result);
}

static string CalculateHash(byte[] data)
{
    using var sha256 = SHA256.Create();
    return Convert.ToHexString(sha256.ComputeHash(data));
}

static async Task<string> CalculateFileHashAsync(string filePath)
{
    byte[] fileData = await File.ReadAllBytesAsync(filePath);
    string hash = await Task.Run(() => CalculateHash(fileData));
    return $"{Path.GetFileName(filePath)} : {hash}";
}

