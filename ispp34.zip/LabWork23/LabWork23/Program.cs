﻿using LabWorkLibrary23;

namespace LabWork23
{
    class Program
    {
        static void Main(string[] args)
        {
            double a = 10, b = 5;
            Console.WriteLine($"сумма: {Maths.Add(a, b)}");
            Console.WriteLine($"разность: {Maths.Subtract(a, b)}");
            Console.WriteLine($"произведение: {Maths.Multiply(a, b)}");
            Console.WriteLine($"частное: {Maths.Divide(a, b)}");
            Console.WriteLine($"площадь прямоугольника: {Maths.RectangleArea(5, 10)}");
            Console.WriteLine($"константа BinaryFactor: {Maths.BinaryFactor}");
        }
    }
}
