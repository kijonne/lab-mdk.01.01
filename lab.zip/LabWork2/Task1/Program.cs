﻿int[] array = { 1, 2, 3, 4, 5 };
int value = 3;

int result = LinearSearch(array, value);
Console.WriteLine($"Элемент {value}, позиция {result}");

static int LinearSearch(int[] array, int value)
{
    for (int i = 0; i < array.Length; i++)
        if (array[i] == value)
            return i;
    return -1;
}


