﻿public class Customer : IPrinter
{
    public string FullName { get; set; }
    public string Address { get; set; }
    public decimal AmountSpent { get; set; }

    public void Print()
    {
        Console.WriteLine($"Заказчик {FullName}, адрес {Address}, потраченная сумма {AmountSpent}");
    }
}
