﻿Customer customer1 = new()
{
    FullName = "Пушкина Александра Андреевна",
    Address = "Архангельск, ул. Урицкого, 2000",
    AmountSpent = 15000
};

Customer customer2 = new()
{
    FullName = "Заморский Олег Ярославович",
    Address = "Архангельск, ул. Мира, 1500",
    AmountSpent = 15000
};


Square square1 = new() { Side = 5 };
Square square2 = new() { Side = 6 };

IPrinter printer;
printer = customer1;
printer.Print();

printer = customer2;
printer.Print();

printer = square1;
printer.Print();

printer = square2;
printer.Print();

Console.WriteLine();
IPrinter[] printers = [ customer1, customer2, square1, square2 ];
foreach (var item in printers) 
{
    item.Print();
    if (item is IFigure figure)
        Console.WriteLine($"Название фигуры {figure.Name}");
}