﻿public interface IFigure
{
    double GetArea();
    double GetPerimeter();
    void PrintInfo();
    string Name { get => "фигура"; }
}