﻿using System.Xml.Linq;

class Customer
{
    private string name;
    private string address;
    private decimal spentAmount;

    public Customer() : this("Неизвестно", "Неизвестно", 0)
    {
    }

    public Customer(string name, string address, decimal spentAmount)
    {
        Name = name;
        Address = address;
        SpentAmount = spentAmount;
    }

    public void DisplayInformation()
    {
        Console.WriteLine($"Имя: {name}");
        Console.WriteLine($"Адрес: {address}");
        Console.WriteLine($"Потраченная сумма: {spentAmount}");
    }

    public string Name
    {
        get => name;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException("Поле с именем не может быть пустым или содержать только пробелы.");
            }
            name = value;
        }
    }

    public string Address
    {
        get => address;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException("Поле с адресом не может быть пустым или содержать только пробелы.");
            }
            address = value;
        }
    }

    public decimal SpentAmount
    {
        get { return spentAmount; }
        set
        {
            if (value < 0)
            {
                throw new ArgumentException("Потраченная сумма не может быть меньше 0.");
            }
            spentAmount = value;
        }
    }
}