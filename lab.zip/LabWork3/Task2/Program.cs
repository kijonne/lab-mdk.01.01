﻿using System.Diagnostics;

double powerResult = Power(5, 3);
Console.WriteLine($"5 в степени 3 = {powerResult}");
static double Power(int x, int n)
{
    Debug.WriteLine($"Вызов n = {n}");
    return n < 0 ? 1 / Power(x, -n) : n == 0 ? 1 : x * Power(x, n - 1);
}
Debug.Assert(Power(5, 3) == 125);
Debug.Assert(Power(2, -2) == 0.25);
Debug.Assert(Power(5, 0) == 1);