﻿using System.Diagnostics;

double fastPowerResult = FastPower(5, 3);
Console.WriteLine($"5 в степени 3 = {fastPowerResult}");
static double FastPower(int x, int n)
{
    Debug.WriteLine($"Вызов n = {n}");
    return n < 0 ? -1 : n == 0 ? 1 : n % 2 == 0 ? FastPower(x, n / 2) * FastPower(x, n / 2) : x * FastPower(x, n - 1);
}
Debug.Assert(FastPower(5, 3) == 125);
Debug.Assert(FastPower(2, -1) == -1);
Debug.Assert(FastPower(5, 0) == 1);