﻿namespace LabWork6
{
    class Customer
    {
        private string Name;
        private string Address;
        private double SpentAmount;

        public Customer() : this("Не указано", "Не указано", 0.0)
        {
        }

        public Customer(string name, string address, double spentAmount)
        {
            Name = name;
            Address = address;
            SpentAmount = spentAmount;
        }

        public object? this[string index]
        {
            get
            {
                return index switch
                {
                    "name" => Name,
                    "address" => Address,
                    "spentAmount" => SpentAmount,
                    _ => null
                };
            }
        }

        public char this[int index]
        {
            get
            {
                if (index >= 0 && index < Name.Length)
                    return Name[index];
                return '\0';
            }
        }

        public void DisplayValues()
        {
            Console.WriteLine($"ФИО: {Name}, Адрес: {Address}, Потраченная сумма: {SpentAmount}");
        }
    }
}

