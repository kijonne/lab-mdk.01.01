﻿public enum Category
{
    Corporative,
    Private
}