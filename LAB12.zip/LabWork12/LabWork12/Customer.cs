﻿public struct Customer
{
    private string _fullName;
    private string _address;
    private double _spentAmount;
    public Category CustomerCategory;

    public Customer(string fullName, string address, double spentAmount, Category category)
    {
        FullName = fullName;
        Address = address;
        SpentAmount = spentAmount >= 0 ? spentAmount : 0;
        CustomerCategory = category;
    }

    public string FullName
    {
        get => _fullName;
        set
        {
            if (!string.IsNullOrEmpty(value))
                _fullName = value;
            else
                throw new ArgumentException("ФИО не может быть пустым.");
        }
    }

    public string Address
    {
        get => _address;
        set
        {
            if (!string.IsNullOrEmpty(value))
                _address = value;
            else
                throw new ArgumentException("Адрес не может быть пустым.");
        }
    }

    public double SpentAmount
    {
        get => _spentAmount;
        set
        {
            if (value >= 0)
                _spentAmount = value;
            else
                throw new ArgumentException("Сумма не может быть отрицательной.");
        }
    }

    public void DisplayInfo()
    {
        Console.WriteLine($"ФИО: {_fullName}, Адрес: {_address}, Потраченная сумма: {_spentAmount}, Категория: {CustomerCategory}");
    }
}