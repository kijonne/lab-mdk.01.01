﻿// 1
Customer customer1 = new();
Customer customer2 = new("Лебедева Марьяна Ростиславовна", "Москва, ул. Вологодская, д. 67", 2000, Category.Private);
customer1.DisplayInfo();
customer2.DisplayInfo();
Console.WriteLine();

// 2 
try
{
    customer1.FullName = "Носов Иван Васильевич";
    customer1.Address = "Астрахань, ул. Мира, д. 10";
    customer1.SpentAmount = 1500;
    customer1.CustomerCategory = Category.Corporative;
    customer1.DisplayInfo();

    customer1.SpentAmount = -500;
}
catch (ArgumentException ex)
{
    Console.WriteLine(ex.Message);
}
Console.WriteLine();

// 4
Customer[] customers = new[]
{
    new("Сидоров Сергей Сергеевич", "Геленджик, ул. Морская, д. 36", 2009, Category.Private),
    customer2,
    new("Алексеева Мария Александровна", "Махачкала, ул. Суворова, д. 16", 500, Category.Corporative)
};

var foundCustomers = Array.FindAll(customers, c => c.CustomerCategory == Category.Private);
Console.WriteLine("Найденные клиенты категории 'Частный':");
foreach (var customer in foundCustomers)
{
    customer.DisplayInfo();
}
Console.WriteLine();

// 5
FileRecord file1 = new() { FileName = "archive.zip", FullPath = "C:\\files\\archive.zip", FileSize = 1012 };
FileRecord file2 = new() { FileName = "audio.mp3", FullPath = "C:\\files\\audio.mp3", FileSize = 567 };
FileRecord file3 = new() { FileName = "video.mov", FullPath = "C:\\files\\video.mov", FileSize = 237 };
FileRecord file4 = new() { FileName = "audio.mp3", FullPath = "C:\\files\\audio.mp3", FileSize = 567 };

Console.WriteLine(file1.ToString());
Console.WriteLine(file2.ToString());
Console.WriteLine(file3.ToString());
Console.WriteLine(file4.ToString());

Console.WriteLine($"Сравнение file1 и file2: {file1.Equals(file2)}");
Console.WriteLine($"Сравнение file2 и file4: {file2.Equals(file4)}");

if (file1 == file2)
    Console.WriteLine("file1 и file2 равны");
else
    Console.WriteLine("file1 и file2 не равны");

if (file2 == file4)
    Console.WriteLine("file2 и file4 равны");
else
    Console.WriteLine("file2 и file4 не равны");


