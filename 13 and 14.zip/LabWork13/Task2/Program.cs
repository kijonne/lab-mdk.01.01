﻿using System.Text.RegularExpressions;
using System.Text;

Console.Write("Введите строку: ");
string inputTwo = Console.ReadLine();

string trimmedString = Regex.Replace(inputTwo.Trim(), @"\s+", " ");
Console.WriteLine("Измененная строка: " + trimmedString);

Console.Write("Выберите регистр (верхний, нижний, инвертированный): ");
string caseOption = Console.ReadLine();

StringBuilder modifiedString = new StringBuilder();
foreach (char c in trimmedString)
{
    if (caseOption == "верхний")
        modifiedString.Append(char.ToUpper(c));
    else if (caseOption == "нижний")
        modifiedString.Append(char.ToLower(c));
    else if (caseOption == "инвертированный")
        modifiedString.Append(char.IsUpper(c) ? char.ToLower(c) : char.ToUpper(c));
    else
        modifiedString.Append(c);
}

Console.WriteLine("Результат с измененным регистром: " + modifiedString.ToString());

Console.WriteLine();