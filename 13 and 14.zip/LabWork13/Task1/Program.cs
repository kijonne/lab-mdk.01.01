﻿using System.Text;
using System.Text.RegularExpressions;

Console.Write("Введите строку: ");
string input = Console.ReadLine();

Console.Write("Введите символ для поиска: ");
char searchChar = Console.ReadKey().KeyChar;
Console.WriteLine();

int totalChars = input.Length;
int charsWithoutSpaces = input.Count(c => !char.IsWhiteSpace(c));
int letterCount = input.Count(c => char.IsLetter(c));
var positions = Enumerable.Range(0, input.Length)
    .Where(i => input[i] == searchChar)
    .ToArray();

Console.WriteLine($"Количество символов: {totalChars}");
Console.WriteLine($"Количество символов без пробелов: {charsWithoutSpaces}");
Console.WriteLine($"Количество букв: {letterCount}");

if (positions.Length > 0)
    Console.WriteLine("Позиции символа: " + string.Join(", ", positions));
else
    Console.WriteLine("Совпадений не найдено.");

Console.WriteLine();