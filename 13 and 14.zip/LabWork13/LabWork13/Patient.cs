﻿class Patient
{
    public string FIO { get; set; }
    public string Policy { get; set; }
    public DateTime BirthDate { get; set; }

    public override string ToString()
    {
        return $"{FIO.ToUpper()};{Policy.PadLeft(9, '0')};{BirthDate:yyyy/MM/dd}";
    }
}