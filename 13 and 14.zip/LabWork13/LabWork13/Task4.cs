﻿
Patient patient = new Patient
{
    FIO = "Мирная Анастасия Антоновна",
    Policy = "12345",
    BirthDate = new DateTime(2014, 2, 3)
};
Console.WriteLine(patient.ToString());

Console.WriteLine();