﻿public class Customer : IComparable, IComparable<Customer>, IEquatable<Customer>, ICloneable
{
    public string FullName { get; set; }
    public string Address { get; set; }
    public decimal AmountSpent { get; set; }

    public int CompareTo(object obj)
    {
        if (obj == null) return 1;

        Customer customer = obj as Customer;
        if (customer != null) return this.AmountSpent.CompareTo(customer.AmountSpent);
        else throw new ArgumentException("Объект не является заказчиком");
    }
     
    public int CompareTo(Customer other)
    {
        if (other == null) return 1;
        return this.AmountSpent.CompareTo(other.AmountSpent);
    }

    public bool Equals(Customer other)
    {
        if (other == null) return false;
        return this.FullName == other.FullName && 
            this.Address == other.Address &&
            this.AmountSpent == other.AmountSpent;
    }

    public object Clone() 
    {
        return new Customer { FullName = this.FullName, Address = this.Address, AmountSpent = this.AmountSpent };
    }

}
