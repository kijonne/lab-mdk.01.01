﻿Customer[] customers = new Customer[]
{
    new Customer
    {
        FullName = "Пушкина Александра Андреевна",
        Address = "Архангельск, ул. Урицкого, 2",
        AmountSpent = 15000
    },

    new Customer
    {
        FullName = "Заморский Олег Ярославович",
        Address = "Архангельск, ул. Мира, 10",
        AmountSpent = 12000
    },
};

Console.WriteLine("Исходный массив: ");
foreach (var customer in customers)
{
    Console.WriteLine($"{customer.FullName}, {customer.Address}, {customer.AmountSpent}");

}

Array.Sort(customers);
Console.WriteLine("Отсортированный массив: ");
foreach (var customer in customers)
{
    Console.WriteLine($"{customer.FullName}, {customer.Address}, {customer.AmountSpent}");
}

var customer1 = new Customer
{
    FullName = "Пушкина Александра Андреевна",
    Address = "Архангельск, ул. Урицкого, 2",
    AmountSpent = 15000
};

var customer2 = new Customer
{
    FullName = "Пушкина Александра Андреевна",
    Address = "Архангельск, ул. Урицкого, 2",
    AmountSpent = 15000
};
Console.WriteLine();
Console.WriteLine($"Сравнение двух объектов: {customer1.Equals(customer2)}");

Console.WriteLine();
Customer clonedCustomer = (Customer)customer1.Clone();
Console.WriteLine($"Клон: {clonedCustomer.FullName}, {clonedCustomer.Address}, {clonedCustomer.AmountSpent}");
